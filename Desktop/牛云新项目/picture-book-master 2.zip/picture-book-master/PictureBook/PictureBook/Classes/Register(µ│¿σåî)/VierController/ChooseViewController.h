//
//  ChooseViewController.h
//  PictureBook
//
//  Created by 陈松松 on 2018/4/18.
//  Copyright © 2018年 zaoliedu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChooseViewController : UIViewController
@property(nonatomic,strong) NSString *age;
@property(nonatomic,strong) NSString *phone;
@property(nonatomic,strong) NSString *name;
@end
