//
//  BannerCell.h
//  PictureBook
//
//  Created by 陈松松 on 2018/4/28.
//  Copyright © 2018年 zaoliedu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BannerCell : UICollectionViewCell

@property(nonatomic,strong) UIImageView *imageView;
@end
