//
//  MyFlowLayout.h
//  FlowersHerbs
//
//  Created by 陈松松 on 2018/3/19.
//  Copyright © 2018年 zaoliedu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyFlowLayout : UICollectionViewFlowLayout

@end
