//
//  CoverView.h
//  PictureBook
//
//  Created by 陈松松 on 2018/4/28.
//  Copyright © 2018年 zaoliedu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CoverView : UIView

+ (void)show;

+ (void)hide;

@end
