//
//  AppDelegate.h
//  PictureBook
//
//  Created by 陈松松 on 2018/4/17.
//  Copyright © 2018年 zaoliedu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

