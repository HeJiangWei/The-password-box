//
//  DekoScene.m
//  deko
//
//  Created by Johan Halin on 4.12.2012.
//  Copyright (c) 2018 Aero Deko. All rights reserved.
//

#import "DekoScene.h"

@implementation DekoScene

@end
