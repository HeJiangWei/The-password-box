//
//  Dekojw0803CreditsViewController.h
//  deko
//
//  Created by Johan Halin on 7.12.2012.
//  Copyright (c) 2018 Aero Deko. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DekoLocalizationManager;

@interface Dekojw0803CreditsViewController : UIViewController

@property (nonatomic) DekoLocalizationManager *localizationManager;

@end
