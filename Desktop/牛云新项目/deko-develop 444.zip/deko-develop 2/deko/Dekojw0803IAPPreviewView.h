//
//  Dekojw0803IAPPreviewView.h
//  deko
//
//  Created by Johan Halin on 9.12.2012.
//  Copyright (c) 2018 Aero Deko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Dekojw0803IAPPreviewView : UIView

@property (nonatomic, readonly) CGFloat previewHeight;

@end
