//
//  main.m
//  deko
//
//  Created by Johan Halin on 26.11.2012.
//  Copyright (c) 2018 Aero Deko. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DekoAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool
	{
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([DekoAppDelegate class]));
	}
}
