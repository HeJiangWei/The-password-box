//
//  Dekojw0803GalleryItemView.h
//  deko
//
//  Created by Johan Halin on 5.12.2012.
//  Copyright (c) 2018 Aero Deko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Dekojw0803GalleryItemView : UIView

@property (nonatomic) UIImage *thumbnail;
@property (nonatomic, assign) BOOL loading;

@end
