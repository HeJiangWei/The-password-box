//
//  Dekojw0803HapticFeedbackController.h
//  deko
//
//  Created by Johan Halin on 17/11/2017.
//  Copyright © 2017 Aero Deko. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Dekojw0803HapticFeedbackController : NSObject

- (void)selectionChanged;
- (void)selectionConfirmed;

@end
