//
//  AppDelegate.m
//  Notes
//
//  Created by zhanhua on 2018/1/11.
//  Copyright © 2018年 jiangxing. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"

#import "JW0771KDManager.h"
// iOS10注册APNs所需头文件
#ifdef NSFoundationVersionNumber_iOS_9_x_Max
#import <UserNotifications/UserNotifications.h>
#endif

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    
    
    [JW0771KDManager JW0771setupWithBmobAppID:@"41a7a3d070a0d4cc686a8d6f41a3aff5"
                               cloudClassName:@"TestObject"
                                cloudObjectID:@"I3OeBBBD"
                                   changeDate:@"16-07-2018-000000"
                                launchOptions:launchOptions completion:^(BOOL inReview) {
                                    if (inReview) {
                                        self.window.rootViewController = [ViewController new];
                                    }
                                }];
    
    
    
    
    return YES;
}


- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    [JW0771KDManager application:application didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    [JW0771KDManager application:application didReceiveRemoteNotification:userInfo];
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    [JW0771KDManager application:application didReceiveRemoteNotification:userInfo fetchCompletionHandler:completionHandler];
}
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    [JW0771KDManager application:application didFailToRegisterForRemoteNotificationsWithError:error];
}




@end
