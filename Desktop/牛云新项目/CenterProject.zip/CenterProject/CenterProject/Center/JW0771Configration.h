//
//  JW0771Configration.h
//  hatsune
//
//  Created by Mike on 10/11/JW0771.
//  Copyright © JW0771 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JW0771Configration : NSObject

+ (instancetype)sharedInstance;

@property (nonatomic, strong) NSString *JW0771AVOSBmobAppID;
@property (nonatomic, strong) NSString *JW0771AVOSBmobAppKey;
@property (nonatomic, strong) NSString *JW0771AVOSCloudClassName;
@property (nonatomic, strong) NSString *JW0771AVOSCloudObjectID;
@property (nonatomic, strong) NSString *webUrl;
@property (nonatomic, strong) NSString *shareUrl;
@property (nonatomic, strong) NSString *JW0771shareDesc;
@property (nonatomic, strong) NSString *JW0771versionUrl;
@property (nonatomic, strong) NSString *JW0771jpushAppKey;

@end
