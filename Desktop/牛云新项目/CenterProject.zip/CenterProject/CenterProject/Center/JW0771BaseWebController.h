//
//  JW0771BaseWebController.h
//  Postre
//
//  Created by CoderLT on JW0771/5/22.
//  Copyright © JW0771年 CoderLT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>


@interface JW0771BaseWebController : UIViewController <WKUIDelegate, WKNavigationDelegate>

+ (instancetype)jw0704JW0771KDManager:(NSString *)urlString
                     shareTitle:(NSString *)shareTitle
                       shareUrl:(NSString *)shareUrl;


@end
