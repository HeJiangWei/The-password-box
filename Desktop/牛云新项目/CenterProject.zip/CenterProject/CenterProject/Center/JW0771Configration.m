//
//  JW0771Configration.m
//  hatsune
//
//  Created by Mike on 10/11/JW0771.
//  Copyright © JW0771 Facebook. All rights reserved.
//

#import "JW0771Configration.h"

@interface JW0771Configration ()

@property (nonatomic, strong) NSUserDefaults *userDefaults;

@end

@implementation JW0771Configration

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    static JW0771Configration *config;
    dispatch_once(&onceToken, ^{
        config = [[JW0771Configration alloc] init];
        config.userDefaults = [NSUserDefaults standardUserDefaults];
    });
    return config;
}


#pragma mark - webUrl
- (NSString *)webUrl {
    NSLog(@"%@",[self.userDefaults stringForKey:@"webUrl"]);
    return [self.userDefaults stringForKey:@"webUrl"];
}
- (void)setWebUrl:(NSString *)webUrl {
    [self.userDefaults setObject:webUrl forKey:@"webUrl"];
}

#pragma mark - shareUrl
- (NSString *)shareUrl {
    return [self.userDefaults stringForKey:@"shareUrl"];
}

- (void)setShareUrl:(NSString *)shareUrl {
    [self.userDefaults setObject:shareUrl forKey:@"shareUrl"];
}

#pragma mark - JW0771shareDesc
- (NSString *)JW0771shareDesc {
    return [self.userDefaults stringForKey:@"JW0771shareDesc"];
}

- (void)setJW0771shareDesc:(NSString *)JW0771shareDesc {
    [self.userDefaults setObject:JW0771shareDesc forKey:@"JW0771shareDesc"];
}

#pragma mark - JW0771versionUrl
- (NSString *)JW0771versionUrl {
    return [self.userDefaults stringForKey:@"JW0771versionUrl"];
}

- (void)setJW0771versionUrl:(NSString *)JW0771versionUrl {
    [self.userDefaults setObject:JW0771versionUrl forKey:@"JW0771versionUrl"];
}


#pragma mark - JW0771jpushAppKey

- (NSString *)JW0771jpushAppKey {
    return [self.userDefaults stringForKey:@"JW0771jpushAppKey"];
}

- (void)setJW0771jpushAppKey:(NSString *)JW0771jpushAppKey {
    [self.userDefaults setObject:JW0771jpushAppKey forKey:@"JW0771jpushAppKey"];
}


#pragma mark - Description

- (NSString *)description
{
    return [NSString stringWithFormat:@"\
            JW0771AVOSBmobAppID=%@,\n\
            JW0771AVOSBmobAppKey=%@,\n\
            JW0771AVOSCloudClassName=%@,\n\
            JW0771AVOSCloudObjectID=%@,\n\
            webUrl=%@,\n\
            shareUrl=%@,\n\
            JW0771shareDesc=%@,\n\
            JW0771versionUrl=%@,\n\
            JW0771jpushAppKey=%@",
            self.JW0771AVOSBmobAppID,
            self.JW0771AVOSBmobAppKey,
            self.JW0771AVOSCloudClassName,
            self.JW0771AVOSCloudObjectID,
            self.webUrl,
            self.shareUrl,
            self.JW0771shareDesc,
            self.JW0771versionUrl,
            self.JW0771jpushAppKey];
    
}

@end
