//
//  ViewController.m
//  WebViewTest
//
//  Created by 伟 on 2018/8/30.
//  Copyright © 2018年 伟. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>

@interface ViewController ()<UIWebViewDelegate,WKUIDelegate,WKNavigationDelegate>

@property (nonatomic,strong)WKWebView *webView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
//    UIWebView *web = [[UIWebView alloc] initWithFrame:self.view.bounds];
//
//    NSURL *url = [NSURL URLWithString:@"https://cp51bb.com/web/base.html"];
//    [web loadRequest:[NSURLRequest requestWithURL:url]];
//    web.delegate = self;
//    [self.view addSubview:web];
//
    
    
    self.webView = [[WKWebView alloc] initWithFrame:self.view.frame];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://cp51bb.com/web/base.html"]]];
    self.webView.navigationDelegate = self;
    self.webView.UIDelegate = self;
    //开了支持滑动返回
    self.webView.allowsBackForwardNavigationGestures = YES;

//    [request setValue:@"xxxx://" forHTTPHeaderField:@"Referer"];

    [self.view addSubview:self.webView];
    

    
    // Do any additional setup after loading the view, typically from a nib.
}


-(void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    
    
    
    NSString *url = [navigationAction.request.URL.absoluteString stringByRemovingPercentEncoding];
    NSString* reUrl=[[webView URL] absoluteString];
    reUrl = url;
    
    if ([url containsString:@"alipay://"]) {
        NSInteger subIndex = 23;
        NSString* dataStr=[url substringFromIndex:subIndex];
        //编码
        NSString *encodeString = [self encodeString:dataStr];
        NSMutableString* mString=[[NSMutableString alloc] init];
        [mString appendString:[url substringToIndex:subIndex]];
        [mString appendString:encodeString];
        
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:mString]];
        
    }
    decisionHandler(WKNavigationActionPolicyAllow);
    return;
}
-(NSString*)encodeString:(NSString*)unencodedString{
    
    // CharactersToBeEscaped = @":/?&=;+!@#$()~',*";
    
    // CharactersToLeaveUnescaped = @"[].";
    
    NSString *encodedString = (NSString *)
    
    CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                              
                                                              (CFStringRef)unencodedString,
                                                              
                                                              NULL,
                                                              
                                                              (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                              
                                                              kCFStringEncodingUTF8));
    
    return encodedString;
    
}


//-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation

//
//- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
//{
//    NSLog(@"+++++++%@,",request.URL.absoluteString);
//
//    (@"------%@,",request.mainDocumentURL);
//
//    return YES;
//}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
