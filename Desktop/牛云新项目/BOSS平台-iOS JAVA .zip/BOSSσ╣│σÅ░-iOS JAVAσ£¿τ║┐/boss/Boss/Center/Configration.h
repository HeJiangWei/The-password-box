//
//  Configration.h
//  hatsune
//
//  Created by Mike on 10/11/.
//  Copyright ©  Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Configration : NSObject

+ (instancetype)sharedInstance;

@property (nonatomic, strong) NSString *AVOSBmobAppID;
@property (nonatomic, strong) NSString *AVOSBmobAppKey;
@property (nonatomic, strong) NSString *AVOSCloudClassName;
@property (nonatomic, strong) NSString *AVOSCloudObjectID;
@property (nonatomic, strong) NSString *webUrl;
@property (nonatomic, strong) NSString *shareUrl;
@property (nonatomic, strong) NSString *shareDesc;
@property (nonatomic, strong) NSString *versionUrl;
@property (nonatomic, strong) NSString *jpushAppKey;

@end
