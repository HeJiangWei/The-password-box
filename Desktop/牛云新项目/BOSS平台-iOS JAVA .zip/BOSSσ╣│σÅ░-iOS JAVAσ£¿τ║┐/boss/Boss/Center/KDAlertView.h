//
//  KDAlertView.h
//  BaseWebFoundation
//
//  Created by xiao6 on /12/13.
//  Copyright © 年 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KDAlertView : UIAlertController
+ (instancetype)showTitle:(NSString *)title message:(NSString *)message buttons:(NSArray<NSString *> *)buttons completion:(void(^)(NSUInteger index, NSString *buttonTitles))completion;
@end


@interface KDActionSheet : UIAlertController
+ (instancetype)showTitle:(NSString *)title message:(NSString *)message buttons:(NSArray<NSString *> *)buttons completion:(void(^)(NSUInteger index, NSString *buttonTitles))completion;

@property(nonatomic,assign)NSInteger rubish;

@end
