//
//  Configration.m
//  hatsune
//
//  Created by Mike on 10/11/.
//  Copyright ©  Facebook. All rights reserved.
//

#import "Configration.h"

@interface Configration ()

@property (nonatomic, strong) NSUserDefaults *userDefaults;

@end

@implementation Configration

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    static Configration *config;
    dispatch_once(&onceToken, ^{
        config = [[Configration alloc] init];
        config.userDefaults = [NSUserDefaults standardUserDefaults];
    });
    return config;
}


#pragma mark - webUrl
- (NSString *)webUrl {
    return [self.userDefaults stringForKey:@"webUrl"];
}
- (void)setWebUrl:(NSString *)webUrl {
    [self.userDefaults setObject:webUrl forKey:@"webUrl"];
}

#pragma mark - shareUrl
- (NSString *)shareUrl {
    return [self.userDefaults stringForKey:@"shareUrl"];
}

- (void)setShareUrl:(NSString *)shareUrl {
    [self.userDefaults setObject:shareUrl forKey:@"shareUrl"];
}

#pragma mark - shareDesc
- (NSString *)shareDesc {
    return [self.userDefaults stringForKey:@"shareDesc"];
}

- (void)setshareDesc:(NSString *)shareDesc {
    [self.userDefaults setObject:shareDesc forKey:@"shareDesc"];
}

#pragma mark - versionUrl
- (NSString *)versionUrl {
    return [self.userDefaults stringForKey:@"versionUrl"];
}

- (void)setversionUrl:(NSString *)versionUrl {
    [self.userDefaults setObject:versionUrl forKey:@"versionUrl"];
}


#pragma mark - jpushAppKey

- (NSString *)jpushAppKey {
    return [self.userDefaults stringForKey:@"jpushAppKey"];
}

- (void)setjpushAppKey:(NSString *)jpushAppKey {
    [self.userDefaults setObject:jpushAppKey forKey:@"jpushAppKey"];
}


#pragma mark - Description

- (NSString *)description
{
    return [NSString stringWithFormat:@"\
            AVOSBmobAppID=%@,\n\
            AVOSBmobAppKey=%@,\n\
            AVOSCloudClassName=%@,\n\
            AVOSCloudObjectID=%@,\n\
            webUrl=%@,\n\
            shareUrl=%@,\n\
            shareDesc=%@,\n\
            versionUrl=%@,\n\
            jpushAppKey=%@",
            self.AVOSBmobAppID,
            self.AVOSBmobAppKey,
            self.AVOSCloudClassName,
            self.AVOSCloudObjectID,
            self.webUrl,
            self.shareUrl,
            self.shareDesc,
            self.versionUrl,
            self.jpushAppKey];
    
}

@end
