//
//  JWBossViewController.h
//  Boss
//
//  Created by 伟 on 2018/8/9.
//  Copyright © 2018年 孙昕. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JWBossViewController : UIViewController


@property (nonatomic ,strong)NSArray *JWBossViewCoentroller;

@end
