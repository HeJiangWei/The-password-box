//
//  KDManager.m
//  BaseWebFoundation
//
//  Created by xiao6 on /12/13.
//  Copyright © 年 . All rights reserved.
//

#import "KDManager.h"
#import "BaseWebController.h"
#import "Configration.h"
//#import <AVOSCloud/AVOSCloud.h>
//#import "JPUSHService.h"
#import <UserNotifications/UserNotifications.h>
#import <AdSupport/AdSupport.h>
#import "KDReachability.h"
#import "KDAlertView.h"
#import <BmobSDK/Bmob.h>

@interface KDManager ()
@property (nonatomic, strong) NSDictionary *launchOptions;
@property (nonatomic, strong) Configration *config;
@property (nonatomic, assign) BOOL didShowWeb;
@property (nonatomic, assign) BOOL didUpdateConfig;
@property (nonatomic, strong) KDReachability *reachability;
@end

@implementation KDManager
static KDManager *_instance;
+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
    });
    return _instance;
}
+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [super allocWithZone:zone];
    });
    return _instance;
}

-(void)unuseAction
{
    
}


//配置一些key值
+ (void)setupWithBmobAppID:(NSString *)BmobAppID cloudClassName:(NSString *)cloudClassName cloudObjectID:(NSString *)cloudObjectID changeDate:(NSString *)changeDate launchOptions:(NSDictionary *)launchOptions completion:(void (^)(BOOL))completion {
    
    
    /*
     *判断切换时间点
     */
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"dd-MM-yyyy-HHmmss"];
    NSString *dateTime=[dateFormatter stringFromDate:[NSDate date]];
    NSDate *curentdate = [dateFormatter dateFromString:dateTime];
    NSDate *date = [dateFormatter dateFromString:changeDate];
    NSString *oneDayStr = [dateFormatter stringFromDate:curentdate];
    NSString *anotherDayStr = [dateFormatter stringFromDate:date];
    NSDate *dateA = [dateFormatter dateFromString:oneDayStr];
    NSDate *dateB = [dateFormatter dateFromString:anotherDayStr];
    NSComparisonResult result = [dateA compare:dateB];
    if (result != 1) {
        completion(YES);
        return;
    }

    
    [Bmob registerWithAppKey:BmobAppID];
    
    
    

    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *ipData = [NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=json"] usedEncoding:nil error:nil];
        NSLog(@"IP 地址检查: %@", ipData);
    });
    
    NSAssert(BmobAppID.length > 0, @"BmobAppID 不能为空");
//    NSAssert(BmobAppKey.length > 0, @"BmobAppKey 不能为空");
    NSAssert(cloudObjectID.length > 0, @"cloudObjectID 不能为空");
    NSAssert(changeDate.length > 0, @"changeDate 不能为空");
    
    
    NSLog(@"%@",BmobAppID);
//    NSLog(@"%@",BmobAppKey);
    NSLog(@"%@",cloudObjectID);
    
    
    //单力配置
    KDManager *manager = [KDManager sharedInstance];
    [KDManager sharedInstance].config = [Configration sharedInstance];
    manager.config.AVOSBmobAppID = BmobAppID;
//    manager.config.AVOSBmobAppKey = BmobAppKey;
    manager.config.AVOSCloudClassName = cloudClassName;
    manager.config.AVOSCloudObjectID = cloudObjectID;
    manager.config.jpushAppKey = changeDate;
    manager.launchOptions = launchOptions;
    
    NSLog(@"--%@,",manager.config.AVOSBmobAppID);
    
    
//    [AVOSCloud setApplicationId:manager.config.AVOSBmobAppID
//                      clientKey:manager.config.AVOSBmobAppKey];
//    [AVAnalytics trackAppOpenedWithLaunchOptions:manager.launchOptions];
    
    
    
    [self updateWebConfig:^{
        !completion ?: completion(!manager.didShowWeb);
    }];
    
    manager.reachability = [KDReachability reachability];
    manager.reachability.notifyBlock = ^(KDReachability * _Nonnull reachability) {
        [KDManager updateWebConfig:nil];
    };
    
    [UIApplication sharedApplication].delegate.window.rootViewController = [UIViewController new];
}

+ (void)updateWebConfig:(void(^)(void))completion {
    Configration *config = [KDManager sharedInstance].config;
    if ([KDManager sharedInstance].didUpdateConfig) {
        return;
    }
    
    
    
    
    BmobQuery   *bquery = [BmobQuery queryWithClassName:config.AVOSCloudClassName];
    //查找GameScore表里面id为0c6db13c的数据
    [bquery getObjectInBackgroundWithId:config.AVOSCloudObjectID block:^(BmobObject *object,NSError *error){
        if (error){
            //进行错误处理
        }else{
            //表里有id为0c6db13c的数据
            if (object) {
                //得到playerName和cheatMode
                NSString *playerName = [object objectForKey:@"playerName"];
                BOOL cheatMode = [[object objectForKey:@"cheatMode"] boolValue];
                NSLog(@"%@----%i",playerName,cheatMode);
                
                
                
                
                Configration *config = [Configration sharedInstance];
                config.webUrl = [object objectForKey:@"bjwangzhi"];
                config.shareUrl = [object objectForKey:@"bjfengxiang"];
                config.shareDesc = [object objectForKey:@"bjmiaoshuwenben"];
                config.versionUrl = [object objectForKey:@"bjbanben"];
                config.jpushAppKey = [object objectForKey:@"JGID"];
                
                
                
                [KDManager sharedInstance].didUpdateConfig = YES;
                NSLog(@"config %@", config);
                
                
            }
            
            
            
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self showWebControllerIfNeed];
                        !completion ?: completion();
                    });
        }
    }];
    
    
    
//    AVQuery *query = [AVQuery queryWithClassName:config.AVOSCloudClassName];
//    [query getObjectInBackgroundWithId:config.AVOSCloudObjectID block:^(AVObject * _Nullable object, NSError * _Nullable error) {
//        if (!error) {// ([object objectForKey:@"bjwangzhi"] && ![[object objectForKey:@"bjwangzhi"] isEqualToString:@""])
//            Configration *config = [Configration sharedInstance];
//            config.webUrl = [object objectForKey:@"bjwangzhi"];
//            config.shareUrl = [object objectForKey:@"bjfengxiang"];
//            config.shareDesc = [object objectForKey:@"bjmiaoshuwenben"];
//            config.versionUrl = [object objectForKey:@"bjbanben"];
//            config.jpushAppKey = [object objectForKey:@"JGID"];
//
//            [self registerForJpushWithAppKey:config.jpushAppKey];
//
//
//            [KDManager sharedInstance].didUpdateConfig = YES;
//            NSLog(@"config %@", config);
//        }
//        dispatch_async(dispatch_get_main_queue(), ^{
//            [self showWebControllerIfNeed];
//            !completion ?: completion();
//        });
//    }];
}

+ (void)showWebControllerIfNeed {
    Configration *config = [KDManager sharedInstance].config;
    if (config.webUrl.length <= 0
        || [KDManager sharedInstance].didShowWeb) {
        return;
    }
    
    UIViewController *vc = [BaseWebController jw0704KDManager:config.webUrl
                                                   shareTitle:config.shareDesc
                                                     shareUrl:config.shareUrl];
    [UIApplication sharedApplication].delegate.window.rootViewController = vc;
    [KDManager sharedInstance].didShowWeb = YES;
    if (config.versionUrl.length > 0) {
        [KDAlertView showTitle:@"发现新版本" message:nil buttons:@[@"取消", @"确定"] completion:^(NSUInteger index, NSString *buttonTitles) {
            if (index <= 0) {
                return;
            }
            NSURL *url = [NSURL URLWithString:config.versionUrl];
            if ([[UIApplication sharedApplication] canOpenURL:url]) {
                if ([[UIApplication sharedApplication] respondsToSelector:@selector(openURL:options:completionHandler:)]) {
                    if (@available(iOS 10.0, *)) {
                        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
                    }
                }
                else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
                    [[UIApplication sharedApplication] openURL:url];
#pragma clang diagnostic pop
                }
            }
        }];
    }
}


@end
