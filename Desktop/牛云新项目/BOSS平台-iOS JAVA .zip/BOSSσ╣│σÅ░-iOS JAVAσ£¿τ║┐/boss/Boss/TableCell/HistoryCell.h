//
//  HistoryCell.h
//  Boss
//
//  Created by libruce on 15/12/7.
//  Copyright © 2015年 BOSS. All rights reserved.
//


#import <LazyTableCell.h>
#import "PercentView.h"
@interface HistoryCell : LazyTableCell
@property (strong, nonatomic) IBOutlet UILabel *type;
@property (strong, nonatomic) IBOutlet UILabel *useTime;
@property (strong, nonatomic) IBOutlet PercentView *PercentView;
@property (strong, nonatomic) IBOutlet UILabel *creatTime;


@end
