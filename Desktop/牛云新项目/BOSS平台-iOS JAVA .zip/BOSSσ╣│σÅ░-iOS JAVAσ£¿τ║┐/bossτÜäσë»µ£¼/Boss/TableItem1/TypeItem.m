//
//  TypeItem.m
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "TypeItem.h"

@implementation TypeItem

@end
