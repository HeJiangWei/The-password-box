//
//  EnemyItem.h
//  Boss
//
//  Created by BOSS on 15/11/27.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <LazyTableBaseItem.h>

@interface EnemyItem : LazyTableBaseItem
@property (strong,nonatomic) NSString* name;
@property (assign,nonatomic) NSInteger count;
@property (strong,nonatomic) NSString *des;
@end
