//
//  TypeItem.h
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <LazyTableBaseItem.h>

@interface TypeItem : LazyTableBaseItem
@property (strong,nonatomic) NSString* name;
@end
