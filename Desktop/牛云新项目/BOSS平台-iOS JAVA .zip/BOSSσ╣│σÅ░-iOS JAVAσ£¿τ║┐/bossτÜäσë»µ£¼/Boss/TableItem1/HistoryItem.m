//
//  HistoryItem.m
//  Boss
//
//  Created by libruce on 15/12/8.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "HistoryItem.h"
#import <JSONModel.h>
@implementation HistoryItem
//+(JSONKeyMapper*)keyMapper
//{
//    return [[JSONKeyMapper alloc] initWithDictionary:@{
//                                                       @"type": @"data.type",
//                                                       @"date": @"data.date",
//                                                       @"use": @"data.use",
//                                                       @"percent":@"data.percent",
//                                                       @"item":@"data.item",
//                                                       }];
//}
@end
