//
//  EnemyItem.m
//  Boss
//
//  Created by BOSS on 15/11/27.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "EnemyItem.h"

@implementation EnemyItem

@end
