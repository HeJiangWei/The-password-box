//
//  TypeCell.m
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "TypeCell.h"
#import "TypeItem.h"
#import "Header.h"
@implementation TypeCell

-(NSNumber*)LazyTableCellHeight:(id)item Path:(NSIndexPath *)path
{
    return @80;
    
}

-(void)LazyTableCellForRowAtIndexPath:(id)item Path:(NSIndexPath *)path
{
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    TypeItem *data=item;
    _lbTitle.text=data.name;
}

-(void)LazyTableCellDidSelect:(id)item Path:(NSIndexPath *)path
{
    
    
    TypeItem *data=item;
    UIViewController *vc=(UIViewController*)data.viewControllerDelegate;
    
    NSString *str = data.name;
    if ([str isEqualToString:@"Objective-C之路"]) {
        str = @"iOS";
    }
    
    [vc pushViewController:@"LevelVC" Param:@{@"type":str}];
    UIImage *img=[self.contentView imageCache];
    CGRect frame=[self.contentView convertRect:self.contentView.bounds toView:[UIApplication sharedApplication].keyWindow];
    UIImageView *view=[[UIImageView alloc] initWithImage:img];
    view.frame=frame;
    view.layer.zPosition=FLT_MAX;
    [[UIApplication sharedApplication].keyWindow addSubview:view];
    [UIView animateWithDuration:0.2 animations:^{
        view.frame=CGRectInset(view.frame, -20, -30);
        view.alpha=0;
    } completion:^(BOOL finished) {
        [view removeFromSuperview];
    }];
}

@end








