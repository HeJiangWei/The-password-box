//
//  EnemyCell.h
//  Boss
//
//  Created by BOSS on 15/11/27.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <LazyTableCell.h>

@interface EnemyCell : LazyTableCell
@property (strong, nonatomic) IBOutlet UILabel *lbName;
@property (strong, nonatomic) IBOutlet UILabel *lbCount;
@property (strong, nonatomic) IBOutlet UILabel *lbDes;

@end
