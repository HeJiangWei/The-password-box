//
//  TypeCell.h
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <LazyTableCell.h>

@interface TypeCell : LazyTableCell
@property (strong, nonatomic) IBOutlet UILabel *lbTitle;

@end
