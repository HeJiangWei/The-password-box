//
//  HistoryCell.h
//  Boss
//
//  Created by libruce on 15/12/7.
//  Copyright © 2015年 BOSS. All rights reserved.
//


#import <LazyTableCell.h>
#import "Percentjw0803View.h"
@interface HistoryCell : LazyTableCell
@property (strong, nonatomic) IBOutlet UILabel *type;
@property (strong, nonatomic) IBOutlet UILabel *useTime;
@property (strong, nonatomic) IBOutlet Percentjw0803View *Percentjw0803View;
@property (strong, nonatomic) IBOutlet UILabel *creatTime;


@end
