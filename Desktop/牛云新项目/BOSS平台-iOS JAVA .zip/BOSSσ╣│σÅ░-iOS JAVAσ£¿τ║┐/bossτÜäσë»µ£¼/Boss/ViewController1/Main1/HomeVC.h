//
//  HomeVC.h
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseViewController.h"
#import <LazyTableView.h>
@interface HomeVC : BaseViewController<LazyTableViewDelegate>
@property (strong, nonatomic) IBOutlet LazyTableView *tableMain;

@end
