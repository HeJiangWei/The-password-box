//
//  MainTabVC.h
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTabVC : UITabBarController

@end
