//
//  PreStartView.h
//  Boss
//
//  Created by BOSS on 15/12/6.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreStartView : UIView
+(void)show:(void (^)())block;
@end
