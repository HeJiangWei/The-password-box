//
//  LevelVC.h
//  Boss
//
//  Created by BOSS on 15/11/26.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseViewController.h"

@interface LevelVC : BaseViewController
@property (strong,nonatomic) NSString* type;
@end
