//
//  LevelView.m
//  Boss
//
//  Created by BOSS on 15/11/26.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "LevelView.h"
@interface Node:NSObject
@property (strong,nonatomic) NSString* title;
@property (assign,nonatomic) CGPoint point;
@end
@implementation Node
@end
@interface LevelView()
{
    NSMutableArray<Node*> *arrNodes;
    NSMutableArray *arrPointX;
    NSInteger indexLast;
    CGFloat y;
    CAShapeLayer *layer;
    CGFloat radius;
    UIButton *btnUser;
    NSInteger iMaxCount;
    UIImageView *imageView;
}
@end
@implementation LevelView
-(instancetype)initWithNodes:(NSArray*)nodes UserIndex:(NSInteger)indexUser MaxCount:(NSInteger)maxCount
{
    if(self=[super init])
    {
        srand((unsigned int)time(0));
        iMaxCount=maxCount;
        radius=([UIScreen mainScreen].bounds.size.height-64)/10;
        arrNodes=[[NSMutableArray alloc] initWithCapacity:30];
        arrPointX=[[NSMutableArray alloc] initWithCapacity:30];
        NSInteger width=[UIScreen mainScreen].bounds.size.width;
        [arrPointX addObject:@(width/4)];
        [arrPointX addObject:@(width/2)];
        [arrPointX addObject:@(width*3/4)];
        indexLast=-1;
        y=[UIScreen mainScreen].bounds.size.height-64-radius/2;
        for(NSString *str in nodes)
        {
            Node *node=[[Node alloc] init];
            node.title=str;
            while (1) {
                NSInteger index=rand()%3;
                if(index!=indexLast)
                {
                    indexLast=index;
                    break;
                }
            }
            node.point=CGPointMake([arrPointX[indexLast] integerValue], y);
            y-=radius;
            [arrNodes addObject:node];
            UIButton *btn=[UIButton buttonWithType:UIButtonTypeSystem];
            btn.tag=arrNodes.count-1;
            btn.frame=CGRectMake(node.point.x-(radius-4)/2, node.point.y-(radius-4)/2, (radius-4), (radius-4));
            btn.layer.zPosition=FLT_MAX;
            [btn setTitle:str forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btn];
            if(btn.tag==indexUser)
            {
                btnUser=[UIButton buttonWithType:UIButtonTypeSystem];
                btnUser.userInteractionEnabled=NO;
                btnUser.tag=indexUser;
                btnUser.frame=CGRectMake(node.point.x-(radius-4)/2, node.point.y-(radius-4)/2, (radius-4), (radius-4));
                btnUser.layer.masksToBounds=YES;
                btnUser.layer.cornerRadius=btnUser.bounds.size.width/2;
                btnUser.layer.zPosition=FLT_MAX;
                [btnUser setBackgroundImage:[UIImage imageNamed:@"userheader"] forState:UIControlStateNormal];
                [self addSubview:btnUser];
            }
        }
        layer = [CAShapeLayer layer];
        layer.fillColor = [UIColor colorWithRed:0.145 green:0.600 blue:1.000 alpha:1.000].CGColor;
        layer.lineWidth =  2.0f;
        layer.lineCap = kCALineCapRound;
        layer.lineJoin = kCALineJoinRound;
        layer.strokeColor = [UIColor colorWithRed:0.145 green:0.600 blue:1.000 alpha:1.000].CGColor;
        [self.layer addSublayer:layer];
        UIBezierPath *path = [UIBezierPath bezierPath];
        [path addArcWithCenter:((Node*)arrNodes[0]).point radius:(radius-4)/2 startAngle:0.0 endAngle:M_PI*2 clockwise:YES];
        for(int i=1;i<arrNodes.count;i++)
        {
            [path moveToPoint:((Node*)arrNodes[i-1]).point];
            [path addLineToPoint:((Node*)arrNodes[i]).point];
            [path addArcWithCenter:((Node*)arrNodes[i]).point radius:(radius-4)/2 startAngle:0.0 endAngle:M_PI*2 clockwise:YES];
        }
        layer.path=path.CGPath;
        layer.strokeStart=0;
        layer.strokeEnd=1;
        imageView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, btnUser.bounds.size.width-5, btnUser.bounds.size.width-5)];
        imageView.backgroundColor=[UIColor clearColor];
        imageView.contentMode=UIViewContentModeScaleAspectFit;
        imageView.layer.zPosition=MAXFLOAT;
        imageView.animationImages=@[[UIImage imageNamed:@"up1.png"],[UIImage imageNamed:@"up2.png"],[UIImage imageNamed:@"up3.png"],[UIImage imageNamed:@"up4.png"],[UIImage imageNamed:@"up5.png"],[UIImage imageNamed:@"up6.png"]];
        imageView.animationDuration=0.8;
        imageView.animationRepeatCount=-1;
        if(btnUser.tag<iMaxCount-1)
        {
            [self addSubview:imageView];
            imageView.center=CGPointMake(arrNodes[btnUser.tag+1].point.x, btnUser.center.y-5);
            [imageView startAnimating];
        }
    }
    return self;
}


-(void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    layer.fillColor = [UIColor colorWithRed:0.145 green:0.600 blue:1.000 alpha:1.000].CGColor;
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeSystem];
    btn.tag=arrNodes.count-1;
    btn.frame=CGRectMake(((Node*)arrNodes.lastObject).point.x-(radius-4)/2, ((Node*)arrNodes.lastObject).point.y-(radius-4)/2, (radius-4), (radius-4));
    btn.layer.zPosition=FLT_MAX;
    [btn setTitle:[anim valueForKey:@"text"] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:btn];
    [UIView animateWithDuration:1 delay:0 usingSpringWithDamping:0.5 initialSpringVelocity:10 options:UIViewAnimationOptionCurveEaseOut animations:^{
        btnUser.center=((Node*)arrNodes[arrNodes.count-2]).point;
        [btnUser.superview bringSubviewToFront:btnUser];
    } completion:^(BOOL finished) {
        btnUser.tag=btnUser.tag+1;
        imageView.hidden=NO;
        imageView.center=CGPointMake(arrNodes[btnUser.tag+1].point.x, btnUser.center.y-5);
    }];

}

-(void)click:(UIButton*)btn
{
    if(_delegateNode && [_delegateNode respondsToSelector:@selector(LevelViewClick:Text:)])
    {
        [_delegateNode LevelViewClick:btn.tag Text:[btn titleForState:UIControlStateNormal]];
    }
}

-(BOOL)updateUser:(NSString*)nextText
{
    imageView.hidden=YES;
    if(arrNodes.count==iMaxCount && btnUser.tag==iMaxCount-1)
    {
        return NO;
    }
    else if(arrNodes.count==iMaxCount && btnUser.tag==iMaxCount-2)
    {
        [UIView animateWithDuration:1 delay:0 usingSpringWithDamping:0.5 initialSpringVelocity:10 options:UIViewAnimationOptionCurveEaseOut animations:^{
            btnUser.center=((Node*)arrNodes[arrNodes.count-1]).point;
            [btnUser.superview bringSubviewToFront:btnUser];
        } completion:^(BOOL finished) {
            btnUser.tag=btnUser.tag+1;
        }];
        return YES;
    }
    while (1) {
        NSInteger index=rand()%3;
        if(index!=indexLast)
        {
            indexLast=index;
            break;
        }
    }
    Node *node=[[Node alloc] init];
    node.title=nextText;
    node.point=CGPointMake([arrPointX[indexLast] integerValue], y);
    y-=radius;
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:((Node*)arrNodes.lastObject).point];
    [path addLineToPoint:node.point];
    [path addArcWithCenter:node.point radius:(radius-4)/2 startAngle:0.0 endAngle:M_PI*2 clockwise:YES];
    [arrNodes addObject:node];
    layer = [CAShapeLayer layer];
    layer.fillColor = [UIColor clearColor].CGColor;
    layer.lineWidth =  2.0f;
    layer.lineCap = kCALineCapRound;
    layer.lineJoin = kCALineJoinRound;
    layer.strokeColor = [UIColor colorWithRed:0.145 green:0.600 blue:1.000 alpha:1.000].CGColor;
    [self.layer addSublayer:layer];
    layer.path=path.CGPath;
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    animation.fromValue = @(0.0);
    animation.toValue = @(1.0);
    animation.duration = 2.0;
    animation.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    animation.delegate=self;
    [animation setValue:nextText forKey:@"text"];
    [layer addAnimation:animation forKey:@"node"];
    return YES;
}
@end








