//
//  AboutUsViewController.h
//  Boss
//
//  Created by libruce on 15/12/10.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseViewController.h"

@interface AboutUsViewController : BaseViewController

@end
