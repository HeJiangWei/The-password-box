//
//  LoginVC.h
//  Boss
//
//  Created by BOSS on 15/11/20.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseViewController.h"

@interface LoginVC : BaseViewController
@property (strong, nonatomic) IBOutlet UITextField *texUsername;
@property (strong, nonatomic) IBOutlet UITextField *texPwd;
- (IBAction)onLogin:(id)sender;
- (IBAction)onRegister:(id)sender;
- (IBAction)onForgot:(id)sender;

@end
