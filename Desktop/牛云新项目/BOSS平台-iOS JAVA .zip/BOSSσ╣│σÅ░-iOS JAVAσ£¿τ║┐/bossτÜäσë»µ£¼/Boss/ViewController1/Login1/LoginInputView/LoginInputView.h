//
//  LoginInputView.h
//  Boss
//
//  Created by BOSS on 15/11/23.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginInputView : UIView
@property (strong,nonatomic) NSString *title;
@property (strong,nonatomic) NSString *imgName;
@end
