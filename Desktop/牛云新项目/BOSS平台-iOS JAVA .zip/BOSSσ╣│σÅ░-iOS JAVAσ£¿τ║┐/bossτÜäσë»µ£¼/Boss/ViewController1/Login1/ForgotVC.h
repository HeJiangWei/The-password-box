//
//  ForgotVC.h
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseViewController.h"

@interface ForgotVC : BaseViewController
@property (strong, nonatomic) IBOutlet UITextField *texUsername;
- (IBAction)onNext:(id)sender;

@end
