//
//  RegisterVC.h
//  Boss
//
//  Created by BOSS on 15/11/23.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseViewController.h"

@interface RegisterVC : BaseViewController
@property (strong, nonatomic) IBOutlet UITextField *texUsername;
- (IBAction)onNext:(id)sender;

@end
