//
//  AnimateInOut.h
//  Boss
//
//  Created by BOSS on 15/12/7.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnimateInOut : NSObject<UIViewControllerAnimatedTransitioning>

@end
