//
//  EnemyPower.m
//  SKTest
//
//  Created by BOSS on 15/12/3.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "EnemyPower.h"
#import "Viewjw0803Texture.h"
#import "Viewjw0803Sence.h"
#import "GameUser.h"
#import "GameEnemy.h"
@implementation EnemyPower
-(instancetype)initWithValue:(NSInteger)value
{
    if(self=[super init])
    {
        self.value=value;
        self.node=[SKSpriteNode spriteNodeWithTexture:[Viewjw0803Texture textureForName:@"enemybullet"] size:CGSizeMake(20, 20)];
        GameEnemy *boss=[[Viewjw0803Sence sharedInstance] valueForKey:@"boss"];
        self.node.position=CGPointMake(boss.node.position.x-boss.node.size.width/2, 30);
        self.node.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:self.node.size];
        self.node.physicsBody.usesPreciseCollisionDetection=YES;
        self.node.physicsBody.affectedByGravity = NO;
        self.node.physicsBody.dynamic=YES;
        self.node.physicsBody.categoryBitMask = EnemyPowerFlag;
        self.node.physicsBody.collisionBitMask = 0x0;
        self.node.physicsBody.contactTestBitMask = UserFlag;
        SKAction *action=[SKAction repeatActionForever:[SKAction moveByX:-80*screenWidthExtra y:0 duration:1]];
        [self.node runAction:action];
        [self.node runAction:[SKAction repeatActionForever:[SKAction rotateByAngle:-10.0/180*31.4 duration:0.1]]];
        [[Viewjw0803Sence sharedInstance] addChild:self.node];
        [self.node runAction:[SKAction playSoundFileNamed:@"敌人子弹.wav" waitForCompletion:NO]];
    }
    return self;
}

-(void)remove
{
    [self.node removeAllActions];
    [self.node runAction:[SKAction playSoundFileNamed:@"男受伤.wav" waitForCompletion:NO]];
    NSMutableArray *arr=[[Viewjw0803Sence sharedInstance] valueForKey:@"arrEnemyPower"];
    [arr removeObject:self];
    __block id obj=self;
    [self.node runAction:[SKAction sequence:@[[SKAction fadeOutWithDuration:0.5],[SKAction removeFromParent]]] completion:^{
        obj=nil;
    }];
}

-(void)hurtUser:(GameUser*)user
{
    user.money-=self.value;
    [self effect];
}


-(void)effect
{
    GameUser *user=[[Viewjw0803Sence sharedInstance] valueForKey:@"user"];
    SKLabelNode *myLabel = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    myLabel.text = [NSString stringWithFormat:@"-%ld",self.value];
    myLabel.fontSize = 15;
    myLabel.position = CGPointMake(user.node.position.x, user.node.size.height+5);
    [myLabel runAction:[SKAction moveByX:0 y:60 duration:2]];
    [myLabel runAction:[SKAction sequence:@[[SKAction fadeOutWithDuration:2],[SKAction removeFromParent]]]];
    [[Viewjw0803Sence sharedInstance] addChild:myLabel];
}
@end







