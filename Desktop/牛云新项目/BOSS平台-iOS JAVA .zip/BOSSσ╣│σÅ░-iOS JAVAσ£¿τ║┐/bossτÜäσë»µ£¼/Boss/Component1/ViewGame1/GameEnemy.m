//
//  GameEnemy.m
//  SKTest
//
//  Created by BOSS on 15/11/30.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "GameEnemy.h"
#import "Viewjw0803Texture.h"
#import "GameDefine.h"
#import "Viewjw0803Sence.h"
#import "GameUser.h"
@interface GameEnemy()
{
    BOOL bBossMove;
    SKLabelNode *bloodNode;
}
@end
@implementation GameEnemy


-(instancetype)initWithName:(NSString*)name Money:(NSInteger)money Speed:(float)speed
{
	if(self=[super init])
    {
        srand((unsigned int)time(0));
        _name=name;
        _money=money;
        _speed=speed;
        
    }
    return  self;
}

-(void)update
{
	if(_node==nil)
    {
        [self initNode];
    }
    else
    {
        if(_bBoss && !bBossMove)
        {
            NSArray *arr=[[Viewjw0803Sence sharedInstance] valueForKey:@"arrEnemy"];
            NSArray *arrInit=[[Viewjw0803Sence sharedInstance] valueForKey:@"arrInitEnemy"];
            if(arr.count==1 && arrInit.count==0 && [arr lastObject]==self)
            {
                if([_node actionForKey:@"move"]==nil)
                {
                    bBossMove=YES;
                    [_node runAction:[SKAction repeatActionForever:[SKAction moveByX:-_speed y:0 duration:1]] withKey:@"move" ];
                    SKAction *action=[SKAction repeatActionForever:[SKAction animateWithTextures:[Viewjw0803Texture atlasForName:_name] timePerFrame:0.2]];
                    [_node runAction:action];
                }
            }
        }
    }
    bloodNode.text=[NSString stringWithFormat:@"%ld",_money];
}

-(void)hurtUser:(GameUser*)user
{
	user.money-=self.money;
    [self effect];
}

-(void)initNode
{
    _node=[SKSpriteNode spriteNodeWithTexture:[[Viewjw0803Texture atlasForName:_name] firstObject]];
    _node.name=_name;
    _node.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:_node.size];
    _node.physicsBody.usesPreciseCollisionDetection=YES;
    _node.physicsBody.affectedByGravity = NO;
    _node.physicsBody.dynamic=YES;
    _node.physicsBody.friction = 1;
    _node.physicsBody.categoryBitMask = EnemyFlag;
    _node.physicsBody.collisionBitMask = 0x0;
    _node.physicsBody.contactTestBitMask = BarrierPowerFlag|BulletPowerFlag|BombPowerFlag|LaserPowerFlag|UserFlag;
    if(_bBoss)
    {
        _node.position = CGPointMake([UIScreen mainScreen].bounds.size.width-_node.size.width/2, _node.size.height/2);
    }
    else
    {
        GameEnemy *boss=[[Viewjw0803Sence sharedInstance] valueForKey:@"boss"];
        _node.position = CGPointMake([UIScreen mainScreen].bounds.size.width-_node.size.width/2-boss.node.size.width, _node.size.height/2);
    }
    if(!_bBoss)
    {
        [_node runAction:[SKAction repeatActionForever:[SKAction moveByX:-_speed y:0 duration:1]] withKey:@"move"];
        SKAction *action=[SKAction repeatActionForever:[SKAction animateWithTextures:[Viewjw0803Texture atlasForName:_name] timePerFrame:0.2]];
        [_node runAction:action];
    }
    [[Viewjw0803Sence sharedInstance] addChild:_node];
    bloodNode=[[SKLabelNode alloc] initWithFontNamed:@"Chalkduster"];
    bloodNode.text=[NSString stringWithFormat:@"%ld",_money];
    bloodNode.fontSize=14;
    bloodNode.fontColor=[UIColor colorWithRed:0.707 green:0.000 blue:0.000 alpha:1.000];
    bloodNode.position=CGPointMake(_node.position.x, _node.position.y+_node.size.height/2);
    [bloodNode setConstraints:@[[SKConstraint distance:[SKRange rangeWithLowerLimit:_node.size.height/2.0 upperLimit:_node.size.height/2.0] toNode:_node],[SKConstraint positionY:[SKRange rangeWithLowerLimit:_node.position.y+_node.size.height/2.0 upperLimit:_node.position.y+_node.size.height/2.0]]]];
    [[Viewjw0803Sence sharedInstance] addChild:bloodNode];
}

-(void)remove
{
    [bloodNode removeFromParent];
    [_node removeAllActions];
    _node.physicsBody.collisionBitMask=0;
    _node.physicsBody.contactTestBitMask=0;
    _node.physicsBody.categoryBitMask=0;
    if([self.name isEqualToString:@"美工"] || [self.name isEqualToString:@"hr"])
    {
        [self.node runAction:[SKAction playSoundFileNamed:@"女死亡.wav" waitForCompletion:NO]];
    }
    else
    {
        [self.node runAction:[SKAction playSoundFileNamed:@"男死亡.wav" waitForCompletion:NO]];
    }
    NSMutableArray *arr=[[Viewjw0803Sence sharedInstance] valueForKey:@"arrEnemy"];
    [arr removeObject:self];
    __block id obj=self;
    [_node runAction:[SKAction sequence:@[[SKAction moveToY:_node.size.width/2 duration:0.3],[SKAction rotateToAngle:M_PI_2 duration:0.5],[SKAction fadeOutWithDuration:0.5],[SKAction removeFromParent]]] completion:^{
        obj=nil;
    }];
}

-(void)effect
{
    GameUser *user=[[Viewjw0803Sence sharedInstance] valueForKey:@"user"];
    SKLabelNode *myLabel = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    myLabel.text = [NSString stringWithFormat:@"-%ld",self.money];
    myLabel.fontSize = 15;
    myLabel.position = CGPointMake(user.node.position.x, user.node.size.height+5);
    [myLabel runAction:[SKAction moveByX:0 y:60 duration:2]];
    [myLabel runAction:[SKAction sequence:@[[SKAction fadeOutWithDuration:2],[SKAction removeFromParent]]]];
    [[Viewjw0803Sence sharedInstance] addChild:myLabel];
}

-(void)pause
{
    if([_node actionForKey:@"move"]!=nil)
    {
        [_node removeActionForKey:@"move"];
    }
}

-(void)resume
{
    if([_node actionForKey:@"move"]==nil)
    {
        [_node runAction:[SKAction repeatActionForever:[SKAction moveByX:-_speed+rand()%(NSInteger)(_speed/5)-(NSInteger)(_speed/5) y:0 duration:1]] withKey:@"move"];
    }
}
@end






