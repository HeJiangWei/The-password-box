//
//  GameDefine.m
//  SKTest
//
//  Created by BOSS on 15/11/30.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "GameDefine.h"
float screenWidthExtra;
NSInteger totleTime;
NSInteger userMoney;
NSInteger totleScore;
NSInteger originTime;
