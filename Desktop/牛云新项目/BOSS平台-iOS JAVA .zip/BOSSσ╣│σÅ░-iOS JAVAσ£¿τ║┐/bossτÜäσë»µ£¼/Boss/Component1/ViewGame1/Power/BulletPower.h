//
//  BulletPower.h
//  SKTest
//
//  Created by BOSS on 15/12/1.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "MyPower.h"

@interface BulletPower : MyPower

@end
