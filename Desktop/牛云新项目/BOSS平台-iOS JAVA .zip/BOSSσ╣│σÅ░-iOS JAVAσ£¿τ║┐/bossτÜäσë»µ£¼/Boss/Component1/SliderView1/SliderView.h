//
//  SliderView.h
//  RunMan-User
//
//  Created by BOSS on 15/5/22.
//  Copyright (c) 2015年 BOSS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SliderView : UIView
-(instancetype)initWithFrame:(CGRect)frame Min:(float)min Max:(float)max;
@property (assign,nonatomic) NSInteger value;
@end
