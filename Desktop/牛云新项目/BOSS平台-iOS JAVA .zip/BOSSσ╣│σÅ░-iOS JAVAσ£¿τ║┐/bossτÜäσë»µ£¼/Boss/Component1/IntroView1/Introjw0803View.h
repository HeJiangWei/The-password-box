//
//  Introjw0803View.h
//  Boss
//
//  Created by BOSS on 15/12/10.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Introjw0803View : UIView
+(void)showTitle:(NSArray*)arr Block:(void (^)())block;
@end
