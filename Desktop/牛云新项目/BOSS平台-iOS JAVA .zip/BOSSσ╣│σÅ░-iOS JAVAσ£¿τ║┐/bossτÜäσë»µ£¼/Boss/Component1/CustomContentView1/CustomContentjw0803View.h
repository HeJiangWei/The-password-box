//
//  CustomContentjw0803View.h
//  Boss
//
//  Created by libruce on 15/12/11.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomContentjw0803View : UIView
@property(nonatomic,strong)UITextView   *contentTextView;
@end
