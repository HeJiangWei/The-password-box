//
//  InputView.h
//  Boss
//
//  Created by BOSS on 15/11/25.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InputView : UIVisualEffectView
+(void)showWithTitle:(NSString*)title TextPlaceHolder:(NSString*)placeholder Block:(BOOL (^)(NSString *text))block;
@end
