//
//  DeleteHistoryReq.m
//  Boss
//
//  Created by libruce on 15/12/12.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "DeleteHistoryReq.h"

@implementation DeleteHistoryReq
-(NSString*)url
{
    return @"/user/deleteHistory";
    
}
@end
@implementation DeleteHistoryRes

@end
