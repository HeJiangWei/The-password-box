//
//  RegisterReq.m
//  Boss
//
//  Created by BOSS on 15/11/23.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "RegisterReq.h"

@implementation RegisterReq
-(NSString*)url
{
    return @"/user/register";
}
@end
