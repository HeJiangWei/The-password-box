//
//  UserQuestionReq.h
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseReq.h"

@interface UserQuestionReq : BaseReq<GET>

@end

@interface UserQuestionRes : BaseRes
@property (strong,nonatomic) NSString<Optional>* data;
@end
