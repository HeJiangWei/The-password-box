//
//  EditPhotoReq.m
//  Boss
//
//  Created by BOSS on 15/11/25.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "EditPhotoReq.h"

@implementation EditPhotoReq
-(NSString*)url
{
    return @"/user/photo";
}
@end


@implementation EditPhotoRes


@end
