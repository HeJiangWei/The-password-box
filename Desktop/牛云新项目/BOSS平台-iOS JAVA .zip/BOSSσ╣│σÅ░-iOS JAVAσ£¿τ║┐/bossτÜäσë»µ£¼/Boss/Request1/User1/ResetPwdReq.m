//
//  ResetPwd.m
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "ResetPwdReq.h"

@implementation ResetPwdReq
-(NSString*)url
{
    return @"/user/reset";
}
@end
