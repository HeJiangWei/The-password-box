//
//  WrongReq.m
//  Boss
//
//  Created by libruce on 15/12/10.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "WrongReq.h"

@implementation WrongReq
-(NSString*)url
{
    return @"/item";
}
@end
@implementation WrongRes



@end
@implementation WrongModel


@end
