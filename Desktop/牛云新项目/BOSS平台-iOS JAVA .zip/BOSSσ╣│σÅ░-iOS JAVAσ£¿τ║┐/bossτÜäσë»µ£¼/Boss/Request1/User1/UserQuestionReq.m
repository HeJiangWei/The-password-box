//
//  UserQuestionReq.m
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "UserQuestionReq.h"

@implementation UserQuestionReq
-(NSString*)url
{
    return @"/user/question";
}
@end

@implementation UserQuestionRes

@end
