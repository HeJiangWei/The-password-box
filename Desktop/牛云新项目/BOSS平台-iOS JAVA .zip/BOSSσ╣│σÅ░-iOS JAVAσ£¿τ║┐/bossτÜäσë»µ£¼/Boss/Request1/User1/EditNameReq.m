//
//  EditNameReq.m
//  Boss
//
//  Created by BOSS on 15/11/25.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "EditNameReq.h"

@implementation EditNameReq
-(NSString*)url
{
    return @"/user/editname";
}
@end
