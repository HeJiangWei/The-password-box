//
//  TypeReq.m
//  Boss
//
//  Created by libruce on 15/12/8.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "TypeReq.h"

@implementation TypeReq
-(NSString*)url
{
    return @"/level/type";
    
}
@end
@implementation TypeModel


@end
@implementation TypeRes


@end
