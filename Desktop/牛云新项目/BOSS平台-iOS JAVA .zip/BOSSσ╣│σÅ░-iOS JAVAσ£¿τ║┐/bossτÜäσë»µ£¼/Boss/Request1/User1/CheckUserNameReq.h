//
//  CheckUserNameReq.h
//  Boss
//
//  Created by BOSS on 15/11/20.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseReq.h"

@interface CheckUserNameReq : BaseReq<GET>

@end

@interface CheckUserNameRes : BaseRes
@property (strong,nonatomic) NSNumber<Optional>* data;
@end
