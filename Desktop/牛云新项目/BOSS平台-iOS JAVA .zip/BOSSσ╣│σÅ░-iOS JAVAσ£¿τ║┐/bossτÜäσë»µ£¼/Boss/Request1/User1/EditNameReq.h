//
//  EditNameReq.h
//  Boss
//
//  Created by BOSS on 15/11/25.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseReq.h"

@interface EditNameReq : BaseReq<PUT>
@property (strong,nonatomic) NSString* name;
@end
