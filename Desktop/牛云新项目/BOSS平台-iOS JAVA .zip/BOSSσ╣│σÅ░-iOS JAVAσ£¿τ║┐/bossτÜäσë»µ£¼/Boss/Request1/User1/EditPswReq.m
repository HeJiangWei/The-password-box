//
//  EditPswReq.m
//  Boss
//
//  Created by libruce on 15/12/7.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "EditPswReq.h"

@implementation EditPswReq
-(NSString*)url
{
    return @"/user/pwd";
}
@end
