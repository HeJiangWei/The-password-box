//
//  ResetPwd.h
//  Boss
//
//  Created by BOSS on 15/11/24.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseReq.h"

@interface ResetPwdReq : BaseReq<PUT>
@property (strong,nonatomic) NSString* answer;
@end
