//
//  CheckUserNameReq.m
//  Boss
//
//  Created by BOSS on 15/11/20.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "CheckUserNameReq.h"

@implementation CheckUserNameReq
-(NSString*)url
{
    return @"/user/check";
}
@end

@implementation CheckUserNameRes

@end
