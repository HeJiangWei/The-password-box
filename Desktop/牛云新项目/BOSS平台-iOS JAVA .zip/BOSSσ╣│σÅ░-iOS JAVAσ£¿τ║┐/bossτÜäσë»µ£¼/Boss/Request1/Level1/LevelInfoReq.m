//
//  LevelInfoReq.m
//  Boss
//
//  Created by BOSS on 15/11/26.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "LevelInfoReq.h"

@implementation LevelInfoReq
-(NSString*)url
{
    return @"/level/info";
}
@end

@implementation LevelInfoRes

@end

@implementation LevelInfoModel

@end
