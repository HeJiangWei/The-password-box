//
//  LevelStartReq.m
//  Boss
//
//  Created by BOSS on 15/12/4.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "LevelStartReq.h"

@implementation LevelStartReq
-(NSString*)url
{
    return @"/level/start";
}
@end

@implementation LevelStartRes

@end

@implementation LevelStartModel

@end

@implementation LevelStartData

@end

@implementation LevelStartAnswer

@end
