//
//  LevelLeaveReq.m
//  Boss
//
//  Created by BOSS on 15/12/6.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "LevelLeaveReq.h"

@implementation LevelLeaveReq
-(NSString*)url
{
    return @"/level/leave";
}
@end

@implementation LevelLeaveModel
@end

@implementation LevelLeaveRes

@end
