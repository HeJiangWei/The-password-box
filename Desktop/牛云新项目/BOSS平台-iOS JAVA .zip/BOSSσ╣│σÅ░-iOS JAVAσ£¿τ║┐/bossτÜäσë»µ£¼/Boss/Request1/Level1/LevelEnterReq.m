//
//  LevelEnterReq.m
//  Boss
//
//  Created by BOSS on 15/11/27.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "LevelEnterReq.h"

@implementation LevelEnterReq
-(NSString*)url
{
    return @"/level/enter";
}
@end

@implementation LevelEnterRes

@end

@implementation LevelEnterModel

@end

@implementation LevelEnterEnemy

@end
