//
//  LevelLeaveReq.h
//  Boss
//
//  Created by BOSS on 15/12/6.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "BaseReq.h"

@interface LevelLeaveReq : BaseReq<POST>
@property (strong,nonatomic) NSString* type;
@property (strong,nonatomic) NSString* level;
@property (assign,nonatomic) NSInteger success;
@property (strong,nonatomic) NSString* createtime;
@property (strong,nonatomic) NSString* usetime;
@property (assign,nonatomic) float percent;
@property (assign,nonatomic) NSInteger score;
@property (strong,nonatomic) NSString* item;
@property (assign,nonatomic) NSInteger challenge;
@end

@interface LevelLeaveModel : JSONModel
@property (assign,nonatomic) NSInteger score;
@property (strong,nonatomic) NSString* level;
@end

@interface LevelLeaveRes : BaseRes
@property (strong,nonatomic) LevelLeaveModel<Optional> *data;
@end









