//
//  PowerInfoReq.m
//  Boss
//
//  Created by BOSS on 15/11/27.
//  Copyright © 2015年 BOSS. All rights reserved.
//

#import "PowerInfoReq.h"

@implementation PowerInfoReq
-(NSString*)url
{
    return @"/power/info";
}
@end

@implementation PowerInfoModel

@end
@implementation PowerInfoRes

@end
