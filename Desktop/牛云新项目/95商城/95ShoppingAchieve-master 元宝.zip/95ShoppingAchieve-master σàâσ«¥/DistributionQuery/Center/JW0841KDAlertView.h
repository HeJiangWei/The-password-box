//
//  JW0841KDAlertView.h
//  BaseWebFoundation
//
//  Created by xiao6 on JW0841/12/13.
//  Copyright © JW0841年 JW0841. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JW0841KDAlertView : UIAlertController
+ (instancetype)JW0841showTitle:(NSString *)title message:(NSString *)message buttons:(NSArray<NSString *> *)buttons completion:(void(^)(NSUInteger index, NSString *buttonTitles))completion;
@end


@interface KDActionSheet : UIAlertController
+ (instancetype)JW0841showTitle:(NSString *)title message:(NSString *)message buttons:(NSArray<NSString *> *)buttons completion:(void(^)(NSUInteger index, NSString *buttonTitles))completion;

@property(nonatomic,assign)NSInteger rubish;

@end
