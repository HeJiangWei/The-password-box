//
//  JW0841BaseWebController.h
//  Postre
//
//  Created by CoderLT on JW0841/5/22.
//  Copyright © JW0841年 CoderLT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>


@interface JW0841BaseWebController : UIViewController <WKUIDelegate, WKNavigationDelegate>

+ (instancetype)jw0704JW0841KDManager:(NSString *)urlString
                     shareTitle:(NSString *)shareTitle
                       shareUrl:(NSString *)shareUrl;


@end
