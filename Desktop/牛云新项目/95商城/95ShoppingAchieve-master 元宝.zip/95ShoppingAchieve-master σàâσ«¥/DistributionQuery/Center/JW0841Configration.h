//
//  JW0841Configration.h
//  hatsune
//
//  Created by Mike on 10/11/JW0841.
//  Copyright © JW0841 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JW0841Configration : NSObject

+ (instancetype)sharedInstance;

@property (nonatomic, strong) NSString *JW0841AVOSBmobAppID;
@property (nonatomic, strong) NSString *JW0841AVOSBmobAppKey;
@property (nonatomic, strong) NSString *JW0841AVOSCloudClassName;
@property (nonatomic, strong) NSString *JW0841AVOSCloudObjectID;
@property (nonatomic, strong) NSString *webUrl;
@property (nonatomic, strong) NSString *shareUrl;
@property (nonatomic, strong) NSString *JW0841shareDesc;
@property (nonatomic, strong) NSString *JW0841versionUrl;
@property (nonatomic, strong) NSString *JW0841jpushAppKey;

@end
