//
//  JW0841Configration.m
//  hatsune
//
//  Created by Mike on 10/11/JW0841.
//  Copyright © JW0841 Facebook. All rights reserved.
//

#import "JW0841Configration.h"

@interface JW0841Configration ()

@property (nonatomic, strong) NSUserDefaults *userDefaults;

@end

@implementation JW0841Configration

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    static JW0841Configration *config;
    dispatch_once(&onceToken, ^{
        config = [[JW0841Configration alloc] init];
        config.userDefaults = [NSUserDefaults standardUserDefaults];
    });
    return config;
}


#pragma mark - webUrl
- (NSString *)webUrl {
    NSLog(@"%@",[self.userDefaults stringForKey:@"webUrl"]);
    return [self.userDefaults stringForKey:@"webUrl"];
}
- (void)setWebUrl:(NSString *)webUrl {
    [self.userDefaults setObject:webUrl forKey:@"webUrl"];
}

#pragma mark - shareUrl
- (NSString *)shareUrl {
    return [self.userDefaults stringForKey:@"shareUrl"];
}

- (void)setShareUrl:(NSString *)shareUrl {
    [self.userDefaults setObject:shareUrl forKey:@"shareUrl"];
}

#pragma mark - JW0841shareDesc
- (NSString *)JW0841shareDesc {
    return [self.userDefaults stringForKey:@"JW0841shareDesc"];
}

- (void)setJW0841shareDesc:(NSString *)JW0841shareDesc {
    [self.userDefaults setObject:JW0841shareDesc forKey:@"JW0841shareDesc"];
}

#pragma mark - JW0841versionUrl
- (NSString *)JW0841versionUrl {
    return [self.userDefaults stringForKey:@"JW0841versionUrl"];
}

- (void)setJW0841versionUrl:(NSString *)JW0841versionUrl {
    [self.userDefaults setObject:JW0841versionUrl forKey:@"JW0841versionUrl"];
}


#pragma mark - JW0841jpushAppKey

- (NSString *)JW0841jpushAppKey {
    return [self.userDefaults stringForKey:@"JW0841jpushAppKey"];
}

- (void)setJW0841jpushAppKey:(NSString *)JW0841jpushAppKey {
    [self.userDefaults setObject:JW0841jpushAppKey forKey:@"JW0841jpushAppKey"];
}


#pragma mark - Description

- (NSString *)description
{
    return [NSString stringWithFormat:@"\
            JW0841AVOSBmobAppID=%@,\n\
            JW0841AVOSBmobAppKey=%@,\n\
            JW0841AVOSCloudClassName=%@,\n\
            JW0841AVOSCloudObjectID=%@,\n\
            webUrl=%@,\n\
            shareUrl=%@,\n\
            JW0841shareDesc=%@,\n\
            JW0841versionUrl=%@,\n\
            JW0841jpushAppKey=%@",
            self.JW0841AVOSBmobAppID,
            self.JW0841AVOSBmobAppKey,
            self.JW0841AVOSCloudClassName,
            self.JW0841AVOSCloudObjectID,
            self.webUrl,
            self.shareUrl,
            self.JW0841shareDesc,
            self.JW0841versionUrl,
            self.JW0841jpushAppKey];
    
}

@end
