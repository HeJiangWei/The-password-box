//
//  ChoosePeopleVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/25.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "Basejw0820ViewController.h"

@interface ChoosePeopleVC : Basejw0820ViewController
@property(nonatomic,copy)void(^peopleIDBlock)(NSString*codeID);
@end
