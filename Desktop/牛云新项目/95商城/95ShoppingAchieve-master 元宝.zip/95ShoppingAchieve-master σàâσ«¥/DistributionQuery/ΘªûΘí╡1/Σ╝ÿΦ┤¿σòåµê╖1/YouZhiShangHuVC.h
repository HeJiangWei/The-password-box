//
//  YouZhiShangHuVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/11.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "Basejw0820ViewController.h"

@interface YouZhiShangHuVC : Basejw0820ViewController
@property(nonatomic,copy)NSString * ziText;//关键字
@end
