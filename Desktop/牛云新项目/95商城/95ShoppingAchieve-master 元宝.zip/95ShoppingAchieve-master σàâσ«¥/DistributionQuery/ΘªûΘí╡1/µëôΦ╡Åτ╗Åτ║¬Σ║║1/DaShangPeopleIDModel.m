//
//  DaShangPeopleIDModel.m
//  DistributionQuery
//
//  Created by Macx on 16/12/22.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "DaShangPeopleIDModel.h"

@implementation DaShangPeopleIDModel
-(id)initWithDaShangPhone:(NSDictionary*)dic{
    self=[super init];
    if (self) {
        _headImage=[Tooljw0820Class isString:[dic objectForKey:@"U_Images"]];
        _nameLabel=[Tooljw0820Class isString:[dic objectForKey:@"U_RealName"]];
        _phoneLabel=[Tooljw0820Class isString:[dic objectForKey:@"U_PhoneNum"]];
    }
    
    return self;
}
@end
