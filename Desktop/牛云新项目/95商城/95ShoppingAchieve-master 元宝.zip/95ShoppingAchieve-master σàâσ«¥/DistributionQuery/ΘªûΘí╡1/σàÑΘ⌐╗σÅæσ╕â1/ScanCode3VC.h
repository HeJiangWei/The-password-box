//
//  ScanCode3VC.h
//  DistributionQuery
//
//  Created by Macx on 16/10/8.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "Basejw0820ViewController.h"
#import "GuanLi3Model.h"
@interface ScanCode3VC : Basejw0820ViewController
/*
 tagg==2的时候代表是从管理修改过来的
 */
@property(nonatomic,assign)NSInteger tagg;
@property(nonatomic,strong)GuanLi3Model * model;
@end
