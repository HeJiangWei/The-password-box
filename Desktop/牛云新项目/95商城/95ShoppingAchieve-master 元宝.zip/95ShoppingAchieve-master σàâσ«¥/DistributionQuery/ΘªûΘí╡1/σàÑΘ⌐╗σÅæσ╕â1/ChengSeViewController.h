//
//  ChengSeViewController.h
//  DistributionQuery
//
//  Created by Macx on 16/12/2.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "Basejw0820ViewController.h"

@interface ChengSeViewController : Basejw0820ViewController
@property(nonatomic,copy)void(^chengSeBlock)(NSString*chengse,NSString*chengSeCode);
@end
