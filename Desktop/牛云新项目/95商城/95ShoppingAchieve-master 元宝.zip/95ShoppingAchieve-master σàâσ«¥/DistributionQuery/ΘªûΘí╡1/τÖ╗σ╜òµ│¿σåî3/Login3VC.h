//
//  Login3VC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/11.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "Basejw0820ViewController.h"

@interface Login3VC : Basejw0820ViewController
//当tagg=2的时候是从入驻发布 过来的
@property(nonatomic,assign)NSInteger tagg;
@end
