//
//  ForGetPwd3VC.h
//  DistributionQuery
//
//  Created by Macx on 16/12/16.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "Basejw0820ViewController.h"

@interface ForGetPwd3VC : Basejw0820ViewController

@end
