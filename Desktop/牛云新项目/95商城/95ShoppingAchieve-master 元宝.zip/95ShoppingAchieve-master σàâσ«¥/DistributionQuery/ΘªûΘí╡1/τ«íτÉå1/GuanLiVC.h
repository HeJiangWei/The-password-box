//
//  GuanLiVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/12.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "Basejw0820ViewController.h"

@interface GuanLiVC : Basejw0820ViewController

@end
