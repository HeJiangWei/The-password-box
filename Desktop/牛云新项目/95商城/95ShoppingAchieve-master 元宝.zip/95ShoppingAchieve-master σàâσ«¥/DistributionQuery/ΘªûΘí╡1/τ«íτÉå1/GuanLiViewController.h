//
//  GuanLiViewController.h
//  DistributionQuery
//
//  Created by Macx on 16/11/25.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "Basejw0820ViewController.h"

@interface GuanLiViewController : Basejw0820ViewController

@end
