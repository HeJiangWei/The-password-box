//
//  GuanLi3Model.m
//  DistributionQuery
//
//  Created by Macx on 16/12/19.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "GuanLi3Model.h"

@implementation GuanLi3Model
-(id)initWithGuanLiDic:(NSDictionary*)dic{
    self=[super init];
    if (self) {
        _titleName=[Tooljw0820Class isString:[dic objectForKey:@"C_Title"]];
        //昵称
          _nikeName=[Tooljw0820Class isString:[dic objectForKey:@"C_ProductName"]];
        //数量
          _numName=[Tooljw0820Class isString:[NSString stringWithFormat:@"%@",[dic objectForKey:@"C_Count"]]];
        //型号
          _xingHaoName=[Tooljw0820Class isString:[NSString stringWithFormat:@"%@",[dic objectForKey:@"C_Type"]]];
        //产地
          _addressName=[Tooljw0820Class isString:[dic objectForKey:@"C_ProductLocation"]];
        //成色
          _chengseName=[Tooljw0820Class isString:[NSString stringWithFormat:@"%@成新",[dic objectForKey:@"C_Degree"]]];
        //成色code
         _chengseCode=[Tooljw0820Class isString:[NSString stringWithFormat:@"%@",[dic objectForKey:@"C_Degree"]]];
        
        
        //详细
          _xiangXiName=[Tooljw0820Class isString:[dic objectForKey:@"C_Description"]];
        
        //整机图片
        _imageurl=[NSString stringWithFormat:@"%@%@",IMAGE_TITLE,[Tooljw0820Class isString:[dic objectForKey:@"C_Img_WholePicHtml"]]];
        //铭牌图片
        _imageurl2=[NSString stringWithFormat:@"%@%@",IMAGE_TITLE,[Tooljw0820Class isString:[dic objectForKey:@"C_Img_MPhtml"]]];
        //经纪人ID
        _jingjiID=[Tooljw0820Class isString:[NSString stringWithFormat:@"%@",[dic objectForKey:@"C_Agent"]]];
        //价格
        _priceName=[Tooljw0820Class isString:[dic objectForKey:@"C_ExpectPrice"]];
        _chaKan=[Tooljw0820Class isString:[NSString stringWithFormat:@"%@",[dic objectForKey:@"C_LookCount"]]];
        _messageID=[Tooljw0820Class isString:[NSString stringWithFormat:@"%@",[dic objectForKey:@"C_Id"]]];
    }
    
    return self;
}
@end
