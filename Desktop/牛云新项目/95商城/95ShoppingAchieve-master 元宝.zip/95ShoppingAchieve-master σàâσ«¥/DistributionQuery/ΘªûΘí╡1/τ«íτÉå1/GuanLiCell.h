//
//  GuanLiCell.h
//  DistributionQuery
//
//  Created by Macx on 16/11/12.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GuanLi3Model.h"
@interface GuanLiCell : UITableViewCell
+(instancetype)cellWithTableView:(UITableView*)tableView CellID:(NSString*)cellID;
@property(nonatomic,strong)UIButton * xiugaiBtn;//修改按钮
@property(nonatomic,strong)UIButton * lastBtn;//修改按钮

@property(nonatomic,strong)UIButton * tejiaBtn;//特价按钮
@property (nonatomic, strong) NSIndexPath *indexPath;
@property (nonatomic, copy) void (^moreButtonClickedBlock)(UIButton *btn,NSIndexPath *indexPath);

@property(nonatomic,strong)GuanLi3Model * model;
@end
