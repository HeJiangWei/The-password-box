//
//  ShangXinModel.m
//  DistributionQuery
//
//  Created by Macx on 16/12/12.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "ShangXinModel.h"

@implementation ShangXinModel
-(id)initWithShangXinDic:(NSDictionary*)dic{
    self=[super init];
    if (self) {
        _title=[Tooljw0820Class isString:[dic objectForKey:@"N_Title"]];
        _time=[Tooljw0820Class isString:[dic objectForKey:@"N_Edit"]];
    }
    
    return self;
}
@end
