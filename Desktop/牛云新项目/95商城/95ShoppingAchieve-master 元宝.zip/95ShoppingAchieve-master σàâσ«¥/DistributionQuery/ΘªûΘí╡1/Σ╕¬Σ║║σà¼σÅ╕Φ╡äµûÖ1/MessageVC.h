//
//  MessageVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/11.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "Basejw0820ViewController.h"

@interface MessageVC : Basejw0820ViewController
@property(nonatomic,assign)NSInteger tagg;
@end
