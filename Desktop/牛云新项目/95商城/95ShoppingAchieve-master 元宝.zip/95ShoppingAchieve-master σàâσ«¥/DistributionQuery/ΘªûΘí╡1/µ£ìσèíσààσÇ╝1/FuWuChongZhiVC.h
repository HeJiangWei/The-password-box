//
//  FuWuChongZhiVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/14.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import "Basejw0820ViewController.h"

@interface FuWuChongZhiVC : Basejw0820ViewController
//tagg==0 短信充值
//tag==1 400充值
@property(nonatomic,assign)NSInteger tagg;
@end
