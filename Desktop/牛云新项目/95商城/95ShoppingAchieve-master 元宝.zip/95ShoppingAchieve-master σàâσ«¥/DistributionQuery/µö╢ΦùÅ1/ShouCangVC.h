//
//  ShouCangVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/12.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "BaseViewController.h"

@interface ShouCangVC : BaseViewController
@property(nonatomic,strong)  UIButton * rightBtn;
@end
