//
//  Basejw0820ViewController.h
//  DistributionQuery
//
//  Created by Macx on 16/10/8.
//  Copyright © 2018年 Wei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Basejw0820ViewController : UIViewController
@property(nonatomic,strong)UIButton * backHomeBtn;
@end
