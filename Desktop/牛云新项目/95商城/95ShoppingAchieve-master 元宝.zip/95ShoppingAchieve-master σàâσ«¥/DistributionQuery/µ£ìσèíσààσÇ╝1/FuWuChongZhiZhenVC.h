//
//  FuWuChongZhiZhenVC.h
//  DistributionQuery
//
//  Created by Macx on 16/12/14.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "BaseViewController.h"

@interface FuWuChongZhiZhenVC : BaseViewController

@end
