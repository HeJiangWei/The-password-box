//
//  SetViewController.h
//  DistributionQuery
//
//  Created by Macx on 16/11/11.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "BaseViewController.h"

@interface SetViewController : BaseViewController

@end
