//
//  FuWuChongZhiVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/14.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "BaseViewController.h"

@interface FuWuChongZhiVC : BaseViewController
//tagg==0 短信充值
//tag==1 400充值
@property(nonatomic,assign)NSInteger tagg;
@end
