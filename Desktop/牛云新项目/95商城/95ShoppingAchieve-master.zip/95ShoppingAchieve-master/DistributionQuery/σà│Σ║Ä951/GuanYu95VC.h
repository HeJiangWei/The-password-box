//
//  GuanYu95VC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/14.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "BaseViewController.h"

@interface GuanYu95VC : BaseViewController

@end
