//
//  YouZhiShangHuVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/11.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "Basejw0803ViewController.h"

@interface YouZhiShangHuVC : Basejw0803ViewController
@property(nonatomic,copy)NSString * ziText;//关键字
@end
