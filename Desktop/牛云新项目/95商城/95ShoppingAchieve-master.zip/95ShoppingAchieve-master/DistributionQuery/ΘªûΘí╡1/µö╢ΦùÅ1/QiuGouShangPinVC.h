//
//  QiuGouShangPinVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/12.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "Basejw0803ViewController.h"

@interface QiuGouShangPinVC : Basejw0803ViewController
@property (nonatomic,strong)UIButton * rightBtn;
@end
