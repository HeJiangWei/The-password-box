//
//  MessageVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/11.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "Basejw0803ViewController.h"

@interface MessageVC : Basejw0803ViewController
@property(nonatomic,assign)NSInteger tagg;
@end
