//
//  ChengSeViewController.h
//  DistributionQuery
//
//  Created by Macx on 16/12/2.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "Basejw0803ViewController.h"

@interface ChengSeViewController : Basejw0803ViewController
@property(nonatomic,copy)void(^chengSeBlock)(NSString*chengse,NSString*chengSeCode);
@end
