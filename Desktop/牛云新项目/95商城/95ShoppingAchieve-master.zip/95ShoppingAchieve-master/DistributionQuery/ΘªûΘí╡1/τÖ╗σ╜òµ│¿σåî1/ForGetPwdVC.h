//
//  ForGetPwdVC.h
//  DistributionQuery
//
//  Created by Macx on 16/12/16.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "Basejw0803ViewController.h"

@interface ForGetPwdVC : Basejw0803ViewController

@end
