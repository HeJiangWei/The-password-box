//
//  LoginVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/11.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "Basejw0803ViewController.h"

@interface LoginVC : Basejw0803ViewController
//当tagg=2的时候是从入驻发布 过来的
@property(nonatomic,assign)NSInteger tagg;
@end
