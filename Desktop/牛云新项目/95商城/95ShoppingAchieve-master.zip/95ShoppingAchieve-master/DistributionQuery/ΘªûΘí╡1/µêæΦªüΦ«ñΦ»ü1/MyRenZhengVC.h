//
//  MyRenZhengVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/11.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "Basejw0803ViewController.h"

@interface MyRenZhengVC : Basejw0803ViewController
{
    UIButton * upbtn;
    UIButton * upbtn2;
    UIButton * upBtn3;
}
@end
