//
//  ShangXinVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/17.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "Basejw0803ViewController.h"

@interface ShangXinVC : Basejw0803ViewController

@end
