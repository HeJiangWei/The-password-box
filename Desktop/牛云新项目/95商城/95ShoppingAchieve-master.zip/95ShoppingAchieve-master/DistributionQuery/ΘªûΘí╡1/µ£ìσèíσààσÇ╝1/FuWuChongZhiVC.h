//
//  FuWuChongZhiVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/14.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "Basejw0803ViewController.h"

@interface FuWuChongZhiVC : Basejw0803ViewController
//tagg==0 短信充值
//tag==1 400充值
@property(nonatomic,assign)NSInteger tagg;
@end
