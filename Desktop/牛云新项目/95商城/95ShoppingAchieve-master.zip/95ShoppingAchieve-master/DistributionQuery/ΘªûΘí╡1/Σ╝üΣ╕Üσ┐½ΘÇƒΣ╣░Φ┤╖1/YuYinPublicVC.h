//
//  YuYinPublicVC.h
//  DistributionQuery
//
//  Created by Macx on 16/11/11.
//  Copyright © 2016年 Macx. All rights reserved.
//

#import "Basejw0803ViewController.h"

@interface YuYinPublicVC : Basejw0803ViewController
//用来区分是标题0，还是本来界面1
@property(nonatomic,assign)NSInteger tagg;
@end
