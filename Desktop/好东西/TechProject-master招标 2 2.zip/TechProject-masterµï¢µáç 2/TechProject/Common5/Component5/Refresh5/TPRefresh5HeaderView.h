//
//  TPRefresh5HeaderView.h
//  TechProject
//
//  Created by zhengjiacheng 787989834838948893895984895on8745345ytr画g画i3fkfkksdkfkaskdfkaksdkfkaskdkfaksdkfkaskdkfkaskdfkaksdkf 2018/1/9.
//  Copyright © 2018年 1122zhengjiacheng. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSUInteger, TPRefreshHeaderState) {
    TPRefreshHeaderStateNone,
    TPRefreshHeaderStatePulling,
    TPRefreshHeaderStateRefreshing,
};
@interface TPRefresh5HeaderView : UIView

@property (nonatomic, copy) void(^handle)(void);
@property (nonatomic, assign) TPRefreshHeaderState status;
- (void)endRefreshing;
@end
