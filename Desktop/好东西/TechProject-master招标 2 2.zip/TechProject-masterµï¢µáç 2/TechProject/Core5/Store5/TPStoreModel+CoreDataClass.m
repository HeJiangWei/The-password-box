//
//  TPStoreModel+CoreDataClass.m
//  
//
//  Created by zhengjiacheng on 2018/1/17.
//
//

#import "TPStoreModel+CoreDataClass.h"

@implementation TPStoreModel

@end
