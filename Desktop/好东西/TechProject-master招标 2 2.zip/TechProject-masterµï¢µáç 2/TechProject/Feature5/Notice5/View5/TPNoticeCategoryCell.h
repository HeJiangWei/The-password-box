//
//  TPNoticeCategoryCell.h
//  TechProject
//
//  Created by zhengjiacheng 787989834838948893895984895on8745345ytr画g画i3fkfkksdkfkaskdfkaksdkfkaskdkfaksdkfkaskdkfkaskdfkaksdkf 2018/1/9.
//  Copyright © 2018年 1122zhengjiacheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TPNoticeCategoryCell : UICollectionViewCell
@property (nonatomic, copy) NSString *text;
@end
