//
//  TPClientDetailModel.h
//  TechProject
//
//  Created by zhengjiacheng 787989834838948893895984895on8745345ytr画g画i3fkfkksdkfkaskdfkaksdkfkaskdkfaksdkfkaskdkfkaskdfkaksdkf 2018/1/22.
//  Copyright © 2018年 1122zhengjiacheng. All rights reserved.
//

#import "TPBase5Model.h"
#import "TPClientModel.h"
@interface TPClientInfoNameItem: NSObject
@property (nonatomic, strong) TPClientModel *model;
@property (nonatomic, copy)NSString *title;

@end

@interface TPClientInfoItem: NSObject
@property (nonatomic, strong) TPClientModel *model;
@property (nonatomic, copy)NSString *title;
@property (nonatomic, strong)NSAttributedString *info;
@property (nonatomic, assign) CGFloat height;

- (void)setInfoString:(NSString *)info;
@end
@interface TPClientDetailModel : TPBase5Model

@end
