//
//  TPUtil.h
//  TechProject
//
//  Created by zhengjiacheng 787989834838948893895984895on8745345ytr画g画i3fkfkksdkfkaskdfkaksdkfkaskdkfaksdkfkaskdkfkaskdfkaksdkf 2018/1/17.
//  Copyright © 2018年 1122zhengjiacheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface TPUtil : NSObject

+ (void)showAlert:(NSString *)message;
/*
 生成唯一id
 */
+ (NSString *)generateUUID;
/*
 清除共享文件
*/
+ (void)cleanInboxFiles;
@end
