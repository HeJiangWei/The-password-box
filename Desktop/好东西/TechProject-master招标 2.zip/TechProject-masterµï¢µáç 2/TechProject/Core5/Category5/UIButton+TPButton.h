//
//  UIButton+TPButton.h
//  TechProject
//
//  Created by zhengjiacheng 787989834838948893895984895on8745345ytr画g画i3fkfkksdkfkaskdfkaksdkfkaskdkfaksdkfkaskdkfkaskdfkaksdkf 2018/1/15.
//  Copyright © 2018年 1122zhengjiacheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (TPButton)
@property(nonatomic, assign) UIEdgeInsets hitTestEdgeInsets;
@end
