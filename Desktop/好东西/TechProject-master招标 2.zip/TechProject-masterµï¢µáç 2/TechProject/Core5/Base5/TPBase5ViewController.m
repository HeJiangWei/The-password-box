//
//  TPBase5ViewController.m
//  TechProject
//
//  Created by zhengjiacheng 787989834838948893895984895on8745345ytr画g画i3fkfkksdkfkaskdfkaksdkfkaskdkfaksdkfkaskdkfkaskdfkaksdkf 2018/1/8.
//  Copyright © 2018年 1122zhengjiacheng. All rights reserved.
//

#import "TPBase5ViewController.h"
#import <MBProgressHUD.h>
#import "TPSnow5View.h"
#import "TPNoDataView.h"
@interface TPBase5ViewController ()<UIGestureRecognizerDelegate>
@property (nonatomic, strong) TPNoDataView *noDataView;
@end

@implementation TPBase5ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [self.navigationController setNavigationBarHidden:YES];
    self.navigationController.interactivePopGestureRecognizer.delegate = (id)self;
    if(@available(iOS 11.0, *)) {
        [[UIScrollView appearance]setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    // Do any additional setup after loading the view.
}

-(void)viewDidAppear:(BOOL) animated{
    [super viewDidAppear:animated];
    [self.view becomeFirstResponder];
}

-(void)viewDidDisappear:(BOOL) animated{
    [super viewDidDisappear:animated];
    [self.view resignFirstResponder];
}

- (void)showLoading{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
}

- (void)hideLoading{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}

- (void)showNoDataView{
    if (!_noDataView) {
        _noDataView = [[TPNoDataView alloc]initWithFrame:CGRectMake(0, TPStatusBarAndNavigationBarHeight, TPScreenWidth, self.view.height - TPStatusBarAndNavigationBarHeight)];
        [self.view addSubview:_noDataView];
    }
    [self.view bringSubviewToFront:_noDataView];
    [_noDataView show];
}

- (void)hideNoDataView{
    [_noDataView hide];
}

#pragma mark 运动开始
-(void)motionBegan:(UIEventSubtype)motion withEvent:(UIEvent *)event{
    if (motion==UIEventSubtypeMotionShake) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [TPSnow5View show];
        });
    }
}

@end
