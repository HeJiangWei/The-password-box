//
//  TPProjectList5VCL.h
//  TechProject
//
//  Created by zhengjiacheng 787989834838948893895984895on8745345ytr画g画i3fkfkksdkfkaskdfkaksdkfkaskdkfaksdkfkaskdkfkaskdfkaksdkf 2018/1/10.
//  Copyright © 2018年 1122zhengjiacheng. All rights reserved.
//

#import "TPBase5ViewController.h"
#import "TPProjectModel.h"
#import "TPProjectRegionModel.h"
#import "TPBarItem.h"
@interface TPProjectList5VCL : TPBase5ViewController
@property (nonatomic, strong) TPProjectRegionModel *region;
- (void)reloadData:(TPBarItem *)item;
@end
