//
//  TPProjectDetailModel.h
//  TechProject
//
//  Created by zhengjiacheng 787989834838948893895984895on8745345ytr画g画i3fkfkksdkfkaskdfkaksdkfkaskdkfaksdkfkaskdkfkaskdfkaksdkf 2018/1/15.
//  Copyright © 2018年 1122zhengjiacheng. All rights reserved.
//

#import "TPBase5Model.h"
#import "TPProjectModel.h"
@interface TPProjectInfoItem: NSObject
@property (nonatomic, strong) TPProjectModel *model;
@property (nonatomic, copy)NSString *title;
@property (nonatomic, strong)NSAttributedString *info;
@property (nonatomic, assign) CGFloat height;

- (void)setInfoString:(NSString *)info;
@end

@interface TPProjectInfoNameItem: NSObject
@property (nonatomic, strong) TPProjectModel *model;
@property (nonatomic, copy)NSString *title;
@end

@interface TPProjectDetailModel : TPBase5Model

@end
