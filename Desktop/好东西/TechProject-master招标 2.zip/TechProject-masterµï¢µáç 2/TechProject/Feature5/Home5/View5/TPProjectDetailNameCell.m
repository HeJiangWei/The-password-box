//
//  TPProjectDetailNameCell.m
//  TechProject
//
//  Created by zhengjiacheng 787989834838948893895984895on8745345ytr画g画i3fkfkksdkfkaskdfkaksdkfkaskdkfaksdkfkaskdkfkaskdfkaksdkf 2018/1/15.
//  Copyright © 2018年 1122zhengjiacheng. All rights reserved.
//

#import "TPProjectDetailNameCell.h"
#import "TPProjectDetailModel.h"

@interface TPProjectDetailNameCell()

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@end

@implementation TPProjectDetailNameCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)configWith:(TPProjectInfoNameItem *)item{
    self.nameLabel.text = item.title;
}

@end
