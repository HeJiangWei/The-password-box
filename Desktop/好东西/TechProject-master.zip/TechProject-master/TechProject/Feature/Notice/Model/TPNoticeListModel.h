//
//  TPNoticeListModel.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/9.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import "TPBaseModel.h"

@interface TPNoticeListModel : TPBaseModel

@end
