//
//  TPNoticeModel.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/8.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import "TPBaseModel.h"

@interface TPNoticeModel : TPBaseModel

@end
