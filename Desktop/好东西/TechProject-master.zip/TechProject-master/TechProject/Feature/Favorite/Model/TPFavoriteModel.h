//
//  TPFavoriteModel.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/23.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import "TPBaseModel.h"

@interface TPFavoriteModel : TPBaseModel

@end
