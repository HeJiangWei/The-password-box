//
//  TPProjectDetailNameCell.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/15.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TPProjectInfoNameItem;
@interface TPProjectDetailNameCell : UITableViewCell
- (void)configWith:(TPProjectInfoNameItem *)item;
@end
