//
//  TPProjectDetailVCL.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/15.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import "TPBaseViewController.h"

@interface TPProjectDetailVCL : TPBaseViewController
@property (nonatomic, copy) NSString *pId;
@end
