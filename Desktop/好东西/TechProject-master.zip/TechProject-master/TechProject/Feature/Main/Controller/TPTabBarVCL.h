//
//  TPTabBarVCL.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/8.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TPTabBarVCL : UITabBarController

@end
