//
//  TPClientNameCell.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/22.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPClientDetailModel.h"
@interface TPClientNameCell : UITableViewCell


- (void)configWith:(TPClientInfoNameItem *)item;
@end
