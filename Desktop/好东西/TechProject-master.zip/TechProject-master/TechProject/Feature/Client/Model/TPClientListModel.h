//
//  TPClientListModel.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/22.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TPBaseModel.h"

@interface TPClientListModel : TPBaseModel
@property (nonatomic, assign)BOOL showFavorite;
@end
