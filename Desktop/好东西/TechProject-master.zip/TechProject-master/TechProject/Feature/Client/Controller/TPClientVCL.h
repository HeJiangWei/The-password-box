//
//  TPClientVCL.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/8.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import "TPBaseViewController.h"
#import "TPBarItem.h"
@interface TPClientVCL : TPBaseViewController
- (void)reloadData:(TPBarItem *)item;
@end
