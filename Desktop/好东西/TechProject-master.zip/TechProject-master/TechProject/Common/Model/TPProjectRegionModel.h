//
//  TPProjectRegionModel.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/22.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TPProjectRegionModel : NSObject
@property (nonatomic, copy) NSString *regionId;
@property (nonatomic, copy) NSString *name;
@end
