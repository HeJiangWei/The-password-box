//
//  TPProjectRegionModel.m
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/22.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import "TPProjectRegionModel.h"
#import "TPEncodeAndDecoded.h"
@implementation TPProjectRegionModel
ENCODED_AND_DECODED()
@end
