//
//  TPCommonViewHelper.h
//  TechProject
//
//  Created by zhengjiacheng on 2018/1/8.
//  Copyright © 2018年 zhengjiacheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface TPCommonViewHelper : NSObject

+ (UIView *)createNavigationBar:(NSString *)title enableBackButton:(BOOL)enableBackButton;

@end
