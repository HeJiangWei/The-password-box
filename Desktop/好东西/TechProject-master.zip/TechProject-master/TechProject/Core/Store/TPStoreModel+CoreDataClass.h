//
//  TPStoreModel+CoreDataClass.h
//  
//
//  Created by zhengjiacheng on 2018/1/17.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface TPStoreModel : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "TPStoreModel+CoreDataProperties.h"
