//
//  EndThankLayer.h
//  nov.1
//
//  Created by 田島僚 on 2015/01/11.
//  Copyright 2015年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface EndThankLayer : CCLayer <UIAlertViewDelegate>{
    
}

+(CCScene *) scene;

@end